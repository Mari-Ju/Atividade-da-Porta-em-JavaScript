var principal = new Array();
var imagem = new Image();
imagem.src = "C:\\Users\\Sony\\Downloads\\21-01\\Porta\\img\\monstros\\sullivan.png";
imagem.width = 59;
imagem.height = 30;
principal[0] = imagem;