class Porta{
    #aberta;
    #cor;

    constructor(aberta, cor){
        this.#aberta = false;
        this.#cor = "";
    }

    abrir(){
        this.#aberta = true;
    }
    getAbrir(){
        return this.#aberta;
    }

    fechar(){
        this.#aberta = false;
    }

    pintar(novaCor){
        this.#cor = novaCor;
    }
    getCor(){
        return this.#cor;
    }
}
var porta1 = new Porta();
var caminho = "";
var estadoPorta = "Fechada";
var cor = "Branco";


function abrir()
{
    
    if(porta1.aberta == true){
        estadoPorta = "Fechada";
    }
    else{
        estadoPorta = "Aberta"
    }
    caminho = "./img/" + cor + estadoPorta + ".jpeg";
    document.getElementById("porta").src = caminho;
    return true; 
    
}

function fechar()
{ 
    if(porta1.aberta == false){
        estadoPorta = "Aberta";
    }
    else{
        estadoPorta = "Fechada"
    }
    caminho = "./img/" + cor + estadoPorta + ".jpeg";
    document.getElementById("porta").src = caminho;
    return true; 

}

function pintar()
{
    cor = document.querySelector('input[name="rdoCor"]:checked').value;
    caminho = "./img/" +  cor + estadoPorta +".jpeg";
    document.getElementById("porta").src = caminho;
    return true;  
}







